package pack_bank;

public interface DBInitializer {
String DRIVER="oracle.jdbc.driver.OracleDriver";
String CON_STRING="jdbc:oracle:thin:@localhost:1521:orcl";
String USERNAME="HR";
String PASSWORD="admin";
} 

